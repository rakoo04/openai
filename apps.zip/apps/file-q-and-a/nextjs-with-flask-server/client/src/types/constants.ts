export const SERVER_ADDRESS = "http://localhost:8080";
